#include <iostream>
using namespace std;

class SimpleList {
    int arr[100];
    int size;
public:
    SimpleList() { size = 0; }

    void add(int x) { arr[size++] = x; }

    void remove(int x) {
        for (int i = 0; i < size; i++) {
            if (arr[i] == x) {
                for (int j = i; j < size - 1; j++)
                    arr[j] = arr[j + 1];
                size--;
                break;
            }
        }
    }

    void display() {
        for (int i = 0; i < size; i++)
            cout << arr[i] << " ";
        cout << endl;
    }

    int getSize() { return size; }
};

int main() {
    SimpleList s;
    s.add(100);
    s.add(200);
    s.add(300);
    s.display();
    s.remove(200);
    s.display();
    cout << "Size: " << s.getSize();
}
