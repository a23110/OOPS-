#include <iostream>
using namespace std;

class SimpleList {
    int arr[100];  // Array to hold list elements
    int size;      // Current number of elements
public:
    SimpleList() { size = 0; }  // Constructor to set size = 0

    void add(int x) { arr[size++] = x; }  // Add new element at end

    void remove(int x) {                   // Remove first matching element
        for (int i = 0; i < size; i++) {
            if (arr[i] == x) {
                for (int j = i; j < size - 1; j++)
                    arr[j] = arr[j + 1];
                size--;
                break;
            }
        }
    }

    void display() {                      // Display all elements
        for (int i = 0; i < size; i++)
            cout << arr[i] << " ";
        cout << endl;
    }

    int getSize() { return size; }        // Return number of elements
};

int main() {
    SimpleList s;
    s.add(100);
    s.add(200);
    s.add(300);
    s.display();
    s.remove(200);
    s.display();
    cout << "Size: " << s.getSize();
}
