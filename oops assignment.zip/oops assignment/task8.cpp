#include <iostream>
using namespace std;

// Base class
class Base {
public:
    void show() { cout << "Base class\n"; }
};

// Derived class overriding show()
class Derived : public Base {
public:
    void show() { cout << "Derived class\n"; }
};

// Overloaded functions (different parameter types)
void print(int x) { cout << "Integer: " << x << endl; }
void print(double x) { cout << "Double: " << x << endl; }

int main() {
    print(5);
    print(3.5);

    Derived d;
    d.show();  // Calls Derived version
}
