#include <iostream>
using namespace std;

class Base {
public:
    void show() { cout << "Base class\n"; }
};

class Derived : public Base {
public:
    void show() { cout << "Derived class\n"; }
};

void print(int x) { cout << "Integer: " << x << endl; }
void print(double x) { cout << "Double: " << x << endl; }

int main() {
    print(5);
    print(3.5);

    Derived d;
    d.show();
}
