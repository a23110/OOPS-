#include <iostream>
using namespace std;

class Sports;  // Forward declaration

class Student {
    int marks;
public:
    Student(int m) { marks = m; }
    friend void total(Student, Sports);  // Friend function declaration
};

class Sports {
    int score;
public:
    Sports(int s) { score = s; }
    friend void total(Student, Sports);
};

// Friend function can access private data of both classes
void total(Student s, Sports sp) {
    cout << "Total: " << s.marks + sp.score << endl;
}

int main() {
    Student st(85);
    Sports sp(15);
    total(st, sp);
}
