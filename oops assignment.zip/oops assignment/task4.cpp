#include <iostream>
using namespace std;

// Base class
class Person {
public:
    string name;
    void setName(string n) { name = n; }
};

// Derived from Person
class Employee : public Person {
public:
    int id;
    void setId(int i) { id = i; }
};

// Derived from Employee
class Manager : public Employee {
public:
    void show() {
        cout << "Name: " << name << ", ID: " << id << endl;
    }
};

int main() {
    Manager m;
    m.setName("ARMAAN");
    m.setId(101);
    m.show();
}
