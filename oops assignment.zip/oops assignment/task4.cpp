#include <iostream>
using namespace std;

class Person {
public:
    string name;
    void setName(string n) { name = n; }
};

class Employee : public Person {
public:
    int id;
    void setId(int i) { id = i; }
};

class Manager : public Employee {
public:
    void show() {
        cout << "Name: " << name << ", ID: " << id << endl;
    }
};

int main() {
    Manager m;
    m.setName("armaan");
    m.setId(101);
    m.show();
}
