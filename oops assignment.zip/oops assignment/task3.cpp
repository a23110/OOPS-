#include <iostream>
using namespace std;

class Shape {
public:
    int width, height;
};

class Rectangle : public Shape {
public:
    int area() { return width * height; }
    int perimeter() { return 2 * (width + height); }
};

int main() {
    Rectangle r;
    r.width = 5;
    r.height = 3;
    cout << "Area: " << r.area() << endl;
    cout << "Perimeter: " << r.perimeter() << endl;
}
