#include <iostream>
using namespace std;

// Base class
class Shape {
public:
    int width, height;
};

// Derived class inheriting Shape
class Rectangle : public Shape {
public:
    int area() { return width * height; }            // Area formula
    int perimeter() { return 2 * (width + height); } // Perimeter formula
};

int main() {
    Rectangle r;
    r.width = 5;
    r.height = 3;
    cout << "Area: " << r.area() << endl;
    cout << "Perimeter: " << r.perimeter() << endl;
}
