#include <iostream>
using namespace std;

// Base class Shape - acts as a common structure for all shapes
class Shape {
public:
    void info() { cout << "This is a shape\n"; }  // Common function for all shapes
};

// Circle derived from Shape
class Circle : public Shape {
public:
    int r;
    Circle(int x) { r = x; }

    void area() { cout << "Circle area: " << 3.14 * r * r << endl; }
};

// Square derived from Shape
class Square : public Shape {
public:
    int s;
    Square(int x) { s = x; }

    void area() { cout << "Square area: " << s * s << endl; }
};

int main() {
    Circle c(3);
    Square s(4);

    c.info();   // From base class
    c.area();   // From derived class
    s.info();   // From base class
    s.area();   // From derived class
}
