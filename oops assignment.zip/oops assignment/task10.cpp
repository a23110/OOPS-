#include <iostream>
using namespace std;

class Shape {
public:
    virtual void area() = 0;
};

class Circle : public Shape {
public:
    int r;
    Circle(int x) { r = x; }
    void area() { cout << "Circle area: " << 3.14 * r * r << endl; }
};

class Square : public Shape {
public:
    int s;
    Square(int x) { s = x; }
    void area() { cout << "Square area: " << s * s << endl; }
};

int main() {
    Circle c(3);
    Square s(4);
    c.area();
    s.area();
}
