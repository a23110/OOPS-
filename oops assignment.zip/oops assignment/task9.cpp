#include <iostream>
using namespace std;

class BankAccount {
    string name;
    int balance;
public:
    BankAccount(string n, int b) { name = n; balance = b; }

    void deposit(int amt) { balance += amt; }
    void withdraw(int amt) { if (amt <= balance) balance -= amt; }

    void show() { cout << name << " Balance: " << balance << endl; }
};

int main() {
    BankAccount a("armaan", 5000);
    a.show();
    a.deposit(100000);
    a.withdraw(2000);
    a.show();
}
