#include <iostream>
using namespace std;

class BankAccount {
    string name;
    int balance;
public:
    BankAccount(string n, int b) { name = n; balance = b; }

    void deposit(int amt) { balance += amt; }  // Add money
    void withdraw(int amt) {                   // Remove money if enough
        if (amt <= balance) balance -= amt;
        else cout << "Not enough balance\n";
    }

    void show() { cout << name << " Balance: " << balance << endl; }
};

int main() {
    BankAccount a("ARMAAN", 50000);
    a.show();
    a.deposit(10080);
    a.withdraw(2000);
    a.show();
}
