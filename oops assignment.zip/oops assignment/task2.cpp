#include <iostream>
using namespace std;

class SimpleMap {
    string keys[50];    // To store keys
    string values[50];  // To store values
    int size;           // Current number of pairs
public:
    SimpleMap() { size = 0; }  // Constructor initializes size

    // Add a key-value pair (update if key exists)
    void insert(string k, string v) {
        for (int i = 0; i < size; i++)
            if (keys[i] == k) { values[i] = v; return; }
        keys[size] = k;
        values[size] = v;
        size++;
    }

    // Display all key-value pairs
    void show() {
        for (int i = 0; i < size; i++)
            cout << keys[i] << " : " << values[i] << endl;
    }
};

int main() {
    SimpleMap m;
    m.insert("name", "armaan");
    m.insert("subject", "OOP");
    m.show();
}
