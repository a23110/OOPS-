#include <iostream>
using namespace std;

class SimpleMap {
    string keys[50];
    string values[50];
    int size;
public:
    SimpleMap() { size = 0; }

    void insert(string k, string v) {
        for (int i = 0; i < size; i++)
            if (keys[i] == k) { values[i] = v; return; }
        keys[size] = k;
        values[size] = v;
        size++;
    }

    void show() {
        for (int i = 0; i < size; i++)
            cout << keys[i] << " : " << values[i] << endl;
    }
};

int main() {
    SimpleMap m;
    m.insert("name", "Armaan");
    m.insert("subject", "OOP");
    m.show();
}
