#include <iostream>
using namespace std;

class Person {
public:
    string name;
    void showName() { cout << "Name: " << name << endl; }
};

class Athlete {
public:
    int medals;
    void showMedals() { cout << "Medals: " << medals << endl; }
};

class SportsPerson : public Person, public Athlete {
public:
    void display() {
        showName();
        showMedals();
    }
};

int main() {
    SportsPerson s;
    s.name = "Armaan";
    s.medals = 3;
    s.display();
}

