#include <iostream>
using namespace std;

// Base class 1
class Person {
public:
    string name;
    void showName() { cout << "Name: " << name << endl; }
};

// Base class 2
class Athlete {
public:
    int medals;
    void showMedals() { cout << "Medals: " << medals << endl; }
};

// Derived class inherits from both Person and Athlete
class SportsPerson : public Person, public Athlete {
public:
    void display() {
        showName();
        showMedals();
    }
};

int main() {
    SportsPerson s;
    s.name = "ARMAAN";
    s.medals = 3;
    s.display();
}
