#include <iostream>
using namespace std;

class Sorter {
    int arr[50];  // Array to hold numbers
    int n;        // Size of array
public:
    // Take input into the array
    void input(int a[], int size) {
        n = size;
        for (int i = 0; i < n; i++) arr[i] = a[i];
    }

    // Bubble Sort logic
    void bubbleSort() {
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (arr[j] > arr[j + 1])
                    swap(arr[j], arr[j + 1]);
    }

    // Display elements
    void display() {
        for (int i = 0; i < n; i++)
            cout << arr[i] << " ";
        cout << endl;
    }
};

int main() {
    Sorter s;
    int a[5] = {99, 25, 56, 22, 11};
    s.input(a, 5);
    cout << "Before sort: "; s.display();
    s.bubbleSort();
    cout << "After sort: "; s.display();
}
